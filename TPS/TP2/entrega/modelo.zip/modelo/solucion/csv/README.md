#### Ejecucion

```
python3 csv.py
```

##### Precondiciones

- Los archivos de salida `.sol` se deben encontrar en el mismo directorio
- Se debe modificar la constante `datos` dentro de `csv.py` para seleccionar los datos básicos o avanzados

##### Salida

- Se generara una carpeta con los archivos de salida para el set de datos.
- Los archivos son `.csv` correspondiente a cada una de las tablas.
